SciHub Access V4 - Installation Guide

1. Unzip this file into a folder on your computer.
2. Open Chrome and go to chrome://extensions
3. Enable "Developer mode" in the top right corner.
4. Click "Load unpacked" and select the unzipped folder.
5. The extension will appear in your toolbar.

How it works:
Click the extension icon in the Chrome toolbar to open the popup.
If a DOI is automatically detected on the page you are viewing, it will be pre filled in the search field.
Otherwise, paste a DOI, a title, or a URL and click Search.

Design:
Main color red B8342A.
